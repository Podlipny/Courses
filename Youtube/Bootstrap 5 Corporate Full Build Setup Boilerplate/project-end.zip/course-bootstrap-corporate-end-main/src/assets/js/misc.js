(function() {

    // Add body class once page has loaded
    window.addEventListener('load', function() {
        document.body.classList.add('page-loaded');
    });
})();