// app-trips.js
(function () {

  "use strict";

  // Creating the Module
  angular.module("app-trips", ["simpleControls"]);

})();