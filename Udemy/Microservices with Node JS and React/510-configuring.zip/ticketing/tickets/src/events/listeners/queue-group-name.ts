export const queueGroupName = 'tickets-service';
