console.log(`I'm ready!`)

onmessage = ({ data }) => console.log('hello from worker', data)