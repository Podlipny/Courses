export default class Service {}
