using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;

namespace GeoLib.Contracts
{
    [ServiceContract]
    public interface IUpdateZipCallback
    {
        [OperationContract(IsOneWay = false)]
        void ZipUpdated(ZipCityData zipCityData);
    }
}
