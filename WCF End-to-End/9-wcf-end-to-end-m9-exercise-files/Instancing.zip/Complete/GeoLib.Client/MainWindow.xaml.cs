﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Windows;
using GeoLib.Proxies;
using GeoLib.Contracts;

namespace GeoLib.Client
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            _Proxy = new StatefulGeoClient();
        }

        StatefulGeoClient _Proxy = null;

        private void btnGetInfo_Click(object sender, RoutedEventArgs e)
        {
            //if (txtZipCode.Text != "")
            //{
            //    GeoClient proxy = new GeoClient();

            //    ZipCodeData data = proxy.GetZipInfo(txtZipCode.Text);
            //    if (data != null)
            //    {
            //        lblCity.Content = data.City;
            //        lblState.Content = data.State;
            //    }

            //    proxy.Close();
            //}

            if (txtZipCode.Text != "")
            {
                ZipCodeData data = _Proxy.GetZipInfo();
                if (data != null)
                {
                    lblCity.Content = data.City;
                    lblState.Content = data.State;
                }
            }
        }

        private void btnGetInRange_Click(object sender, RoutedEventArgs e)
        {
            if (txtZipCode.Text != "" && txtRange.Text != "")
            {
                IEnumerable<ZipCodeData> data = _Proxy.GetZips(int.Parse(txtRange.Text));
                if (data != null)
                    lstZips.ItemsSource = data;
            }
        }

        private void btnPush_Click(object sender, RoutedEventArgs e)
        {
            if (txtZipCode.Text != "")
            {
                _Proxy.PushZip(txtZipCode.Text);
            }
        }
    }
}
