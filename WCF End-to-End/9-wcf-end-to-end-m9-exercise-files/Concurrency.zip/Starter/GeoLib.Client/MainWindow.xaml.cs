﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Windows;
using GeoLib.Proxies;
using GeoLib.Contracts;
using System.Threading;
using System.Threading.Tasks;

namespace GeoLib.Client
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            _SyncContext = SynchronizationContext.Current;
            _Proxy = new GeoClient();
        }

        GeoClient _Proxy = null;
        SynchronizationContext _SyncContext = null;

        private void btnGetInfo_Click(object sender, RoutedEventArgs e)
        {
            if (txtZipCode.Text != "")
            {
                string zipCode = txtZipCode.Text;

                if (_Proxy.State != CommunicationState.Opened)
                    _Proxy.Open();

                Thread thread = new Thread(() =>
                {
                    ZipCodeData data = _Proxy.GetZipInfo(zipCode);
                    if (data != null)
                    {
                        SendOrPostCallback callback = new SendOrPostCallback(arg =>
                        {
                            lblCity.Content = data.City;
                            lblState.Content = data.State;
                        });

                        _SyncContext.Send(callback, null);
                    }
                });
                
                thread.IsBackground = true;
                thread.Start();
            }
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            if (_Proxy.State == CommunicationState.Opened)
                _Proxy.Close();

            base.OnClosing(e);
        }
    }
}
