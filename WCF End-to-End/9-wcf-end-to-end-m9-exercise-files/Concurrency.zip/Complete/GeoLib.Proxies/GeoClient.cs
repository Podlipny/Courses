﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using GeoLib.Contracts;

namespace GeoLib.Proxies
{
    public class GeoClient : ClientBase<IGeoService>, IGeoService
    {
        public GeoClient()
        {            
        }

        public GeoClient(string endpointName)
            : base(endpointName)
        {            
        }

        public GeoClient(Binding binding, EndpointAddress address)
            : base(binding, address)
        {            
        }

        public ZipCodeData GetZipInfo(string zip)
        {
            return Channel.GetZipInfo(zip);
        }
    }
}
